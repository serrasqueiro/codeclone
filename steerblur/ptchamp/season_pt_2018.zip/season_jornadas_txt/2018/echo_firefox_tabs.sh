#!/bin/sh


echo_tabs ()
{
 local J=1
 local MAX_J=34
 local OPT="-n"

 while [ $J -le $MAX_J ]; do
	# "http://www.zerozero.pt/edition.php?jornada_in=6&id_edicao=125220"
	echo $OPT " \"http://www.zerozero.pt/edition.php?jornada_in=$J&id_edicao=125220\""
	###	J=$(expr $J + 1)
	let J++
 done
}


echo_tabs


